function buscarMunicipio(event, form) {
    event.preventDefault();
    const inputMunicipio = form.Municipio;
    if (inputMunicipio) {
        const Municipio = inputMunicipio.value;
        if (Municipio.length === 20) {
            const URL = `https://transparencia.tce.sp.gov.br/api/${Municipio}/municipios`;
            fetch(URL)
                .then(resposta => resposta.json())
                .then(data => mostrarResposta(data))
                .catch(erro => console.error(erro));
        }
    }
}

function mostrarResposta(Municipio) {
    const mensagem = `
    orgao: ${Municipio.orgao},
    mes: ${Municipio.mes},
    ds_fonte_recurso	: ${Municipio.ds_fonte_recurso},
    ds_cd_aplicacao_fixo: ${Municipio.ds_cd_aplicacao_fixo},
    ds_alinea: ${Municipio.ds_alinea},
    ds_subalinea: ${Municipio.ds_subalinea},
    vl_arrecadacao: ${Municipio.vl_arrecadacao},
    `;
    alert(mensagem);
}

function removeAcentos(s) {
    var map={"â":"a","Â":"A","à":"a","À":"A","á":"a","Á":"A","ã":"a","Ã":"A",
    "ê":"e","Ê":"E","è":"e","È":"E","é":"e","É":"E","î":"i","Î":"I","ì":"i",
    "Ì":"I","í":"i","Í":"I","õ":"o","Õ":"O","ô":"o","Ô":"O","ò":"o","Ò":"O",
    "ó":"o","Ó":"O","ü":"u","Ü":"U","û":"u","Û":"U","ú":"u","Ú":"U","ù":"u",
    "Ù":"U","ç":"c","Ç":"C"};

    let s1 = s.replace(/[\W\[\] ]/g, function(a){
        return map[a]||a
    }); 
    
    return s1.split(' ').join('+');
}